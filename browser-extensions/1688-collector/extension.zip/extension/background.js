chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'TMINOS_IMPORT_HTML') return;

  (async () => {
    const { url, html, extractedJson } = message;

    if (typeof url !== 'string' || !url) {
      sendResponse({ ok: false, error: 'Missing url' });
      return;
    }
    if (typeof html !== 'string') {
      sendResponse({ ok: false, error: 'Missing html' });
      return;
    }
    if (typeof extractedJson !== 'string') {
      sendResponse({ ok: false, error: 'Missing extractedJson' });
      return;
    }

    const payload = {
      html,
      extractedJson
    };

    let resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json;charset=utf-8'
      },
      body: JSON.stringify(payload)
    });

    let uploadMode = 'json';
    if (resp.status === 415) {
      resp = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8'
        },
        body: html
      });
      uploadMode = 'text/plain';
    }

    const text = await resp.text().catch(() => '');

    sendResponse({
      ok: resp.ok,
      status: resp.status,
      statusText: resp.statusText,
      bodyText: text,
      uploadMode
    });
  })().catch((err) => {
    sendResponse({ ok: false, error: err?.message || String(err) });
  });

  // keep the message channel open for async response
  return true;
});
